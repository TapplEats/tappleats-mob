export const updateObj = (oldObj, updatedProps) => ({
  ...oldObj,
  ...updatedProps,
})