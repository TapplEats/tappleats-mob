import React from 'react'

import PropTypes from 'prop-types'

// import DateFnsAdapter from '@date-io/date-fns'
// import { isValid } from 'date-fns'

const FormElement = ({
  valid,
  shouldValidate,
  touched,
  errorMessage,
  value,
  changed,
  blured,
  elementSetup,
  label,
  elementOptions,
  elementType,
  grid,
  disabled,
  formElementSpacing,
}) => {
  let inputEl = null
  let chipsArray = []
  // const dateFns = new DateFnsAdapter()
  // let dateValue = null

  // switch (elementType) {
  //   case ('textarea'):
  //     inputEl = (
  //       <>
  //         <TextField
  //           className={`${inputClasses} ${rtlClass}`}
  //           label={label}
  //           multiline
  //           maxRows={4}
  //           value={value}
  //           onChange={changed}
  //           error={touched && !valid}
  //           helperText={errorMessage && errorMessage.var}
  //           disabled={disabled}
  //           fullWidth={grid.fullWidth}
  //           {...elementSetup}
  //         />
  //         {elementSetup.help && (
  //           <Typography
  //             className={classes.help}
  //             style={{
  //               ...elementSetup.helpbackground ? { backgroundColor: elementSetup.helpbackground } : {},
  //               ...elementSetup.helpcolor ? { color: elementSetup.helpcolor } : {},
  //             }}
  //           >
  //             <HelpOutlineIcon
  //               style={{
  //                 ...elementSetup.helpcolor ? { color: elementSetup.helpcolor } : {},
  //               }}
  //             />
  //             {elementSetup.help}
  //           </Typography>
  //         )}
  //       </>
  //     )
  //     break
  //   case ('textarea-auto-size'):
  //     inputEl = (
  //       <TextareaAutosize
  //         className={`${inputClasses} ${rtlClass}`}
  //         label={label}
  //         multiline
  //         rowsMin={4}
  //         value={value}
  //         onChange={changed}
  //         error={!valid}
  //         helperText={errorMessage}
  //         disabled={disabled}
  //         fullWidth={grid.fullWidth}
  //         {...elementSetup}
  //       />
  //     )
  //     break
  //   case ('checkbox'):
  //     inputEl = (
  //       <FormGroup row>
  //         <FormControlLabel
  //           control={(
  //             <Checkbox
  //               checked={value}
  //               color="primary"
  //               onChange={changed}
  //               {...elementSetup}
  //             />
  //           )}
  //           label={label}
  //           className={`${classes.formLabel} ${language.direction === 'rtl' ? classes.arabicFont : ''}`}
  //           dir={language.direction}
  //         />
  //         {touched && !valid && (
  //           <FormHelperText className="Mui-error">{errorMessage && errorMessage.var}</FormHelperText>
  //         )}
  //       </FormGroup>
  //     )
  //     break
  //   case ('checkboxGroup'):
  //     inputEl = (
  //       <Box>
  //         <Typography className={classes.checkboxGroupLabel}>
  //           {label}
  //         </Typography>
  //         <FormGroup row className={classes.checkboxGroupContainer} onChange={changed}>
  //           {createCheckboxGroupOptions(elementOptions, value)}
  //         </FormGroup>
  //       </Box>
  //     )
  //     break
  //   case ('select'):
  //     inputEl = (
  //       <>
  //         <InputLabel htmlFor={elementSetup.name} className={`${inputClasses} ${rtlClass}`}>{label}</InputLabel>
  //         <Select
  //           native
  //           error={touched && !valid}
  //           value={value}
  //           onChange={changed}
  //           fullWidth={grid.fullWidth}
  //           disabled={disabled}
  //           className={`${classes.select} ${rtlClass} ${language.direction === 'rtl' ? classes.arabicFont : ''}`}
  //           MenuProps={{ classes: { paper: classes.select, list: classes.select } }}
  //           inputProps={{
  //             name: elementSetup.name,
  //             id: elementSetup.name,
  //           }}
  //         >
  //           {!elementSetup.noemptyopts && (
  //             <option aria-label="None" value="" />
  //           )}
  //           {elementSetup.sort ? createSelectOptionsSorted(elementOptions) : createSelectOptions(elementOptions)}
  //         </Select>
  //         <FormHelperText className={`Mui-error ${classes.rtlLabel}`}>{errorMessage && errorMessage.var}</FormHelperText>
  //       </>
  //     )
  //     break
  //   case ('autoComplete'):
  //     inputEl = (
  //       <Autocomplete
  //         multiple
  //         id="tags-standard"
  //         options={elementOptions}
  //         getOptionLabel={tag => tag.title}
  //         defaultValue={value}
  //         renderInput={params => (
  //           <TextField
  //             {...params}
  //             variant="standard"
  //             label="Multiple values"
  //             placeholder="Favorites"
  //             fullWidth={grid.fullWidth}
  //             disabled={disabled}
  //           />
  //         )}
  //       />
  //     )
  //     break
  //   case ('tags'):
  //     chipsArray = []
  //     if (typeof value === 'string' && value !== '') {
  //       chipsArray = value.split(',')
  //     }
  //     inputEl = (
  //       <>
  //         <ChipInput
  //           defaultValue={chipsArray}
  //           label={label}
  //           onChange={changed}
  //           error={!valid}
  //           className={`${inputClasses} ${classes.chipInputEl} ${rtlClass} ${elementSetup.disabled && classes.disabledInput}`}
  //         />
  //         <FormHelperText>{errorMessage}</FormHelperText>
  //       </>
  //     )
  //     break
  //   case ('imageUpload'):
  //     inputEl = (
  //       <>
  //         {/* eslint-disable */}
  //         {elementSetup.showLabel && (
  //           <label className={classes.imageUploadLabel}>Profile image</label>
  //         )}
  //         {/* eslint-disable */}
  //         <Box className={`${classes.imageUploadContainer} ${elementSetup.compact ? classes.compactImageUploadContainer : ''}`}>
  //           <ImageUploader
  //             {...elementSetup}
  //             withIcon={false}
  //             withPreview={false}
  //             singleImage
  //             onChange={changed}
  //             imgExtension={['.jpg', '.png', '.jpeg']}
  //             label={elementSetup.label}
  //             buttonText={imageUploadValue ? elementSetup.changeButtonText : elementSetup.selectButtonText}
  //             className={`
  //               ${classes.imageUploadBox}
  //               ${!imageUploadValue ? classes.imageUploadBoxEmpty : ''}
  //               ${elementSetup.stateClass === 'cropActive' ? classes.imageUploadBoxCrop : ''}
  //               ${elementSetup.styleClass === 'light' ? classes.imageUploadBoxLight : ''}
  //             `}
  //             maxFileSize={31457280}
  //           />
  //           {elementSetup.withView && (
  //             <Avatar alt="Avatar" src={value} className={classes.imageUploadAvatar} onClick={() => clickUpload()} />
  //           )}
  //         </Box>
  //       </>
  //     )
  //     break
  //   case ('slider'):
  //     inputEl = (
  //       <>
  //         <Typography id="discrete-slider" gutterBottom>
  //           {label}
  //         </Typography>
  //         <Slider
  //           value={parseInt(value, 10) || 0}
  //           aria-valuetext={value.toString()}
  //           aria-labelledby="discrete-slider"
  //           valueLabelDisplay="on"
  //           step={10}
  //           onChange={(e, sliderValue) => changed(sliderValue)}
  //           marks
  //           min={0}
  //           max={100}
  //           classes={{
  //             root: classes.sliderRoot,
  //             track: classes.sliderTrack,
  //             rail: classes.sliderRail,
  //             thumb: classes.sliderThumb,
  //             mark: classes.sliderMark,
  //             valueLabel: classes.valueLabel,
  //             markLabel: classes.markLabel,
  //           }}
  //         />
  //       </>
  //     )
  //     break
  //   case ('date'):
  //     if (value) {
  //       if (isValid(value)) {
  //         dateValue = dateFns.date(value)
  //       } else {
  //         dateValue = dateFns.date(value.toDate())
  //       }
  //     }
  //     inputEl = (
  //       <>
  //         <MuiPickersUtilsProvider utils={DateFnsAdapter}>
  //           <DatePicker
  //             disableFuture={elementSetup.disableFuture || false}
  //             disablePast={elementSetup.disablePast || false}
  //             maxDate={elementSetup.maxDate || null}
  //             label={label}
  //             className={`${classes.date} ${rtlClass}`}
  //             DialogProps={{
  //               PaperProps: {
  //                 classes: {
  //                   root: classes.datePickerDialog,
  //                 },
  //               },
  //             }}
  //             value={value ? dateValue : null}
  //             onChange={changed}
  //             openTo="year"
  //             format="dd - MM - yyyy"
  //             views={['year', 'month', 'date']}
  //             clearable
  //           />
  //         </MuiPickersUtilsProvider>
  //       </>
  //     )
  //     break
  //   case ('dateTime'):
  //     if (value) {
  //       if (isValid(value)) {
  //         dateValue = dateFns.date(value)
  //       } else {
  //         dateValue = dateFns.date(value.toDate())
  //       }
  //     }
  //     inputEl = (
  //       <>
  //         <MuiPickersUtilsProvider utils={DateFnsAdapter}>
  //           <DateTimePicker
  //             disableFuture={elementSetup.disableFuture || false}
  //             disablePast={elementSetup.disablePast || false}
  //             maxDate={elementSetup.maxDate || new Date('2100-01-01')}
  //             minDateMessage="Date reached"
  //             label={label}
  //             showTodayButton
  //             className={`${classes.date} ${rtlClass}`}
  //             DialogProps={{
  //               PaperProps: {
  //                 classes: {
  //                   root: classes.datePickerDialog,
  //                 },
  //               },
  //             }}
  //             value={value ? dateValue : null}
  //             onChange={changed}
  //             format="dd - MM - yyyy (h:mm aa)"
  //             clearable
  //           />
  //         </MuiPickersUtilsProvider>
  //       </>
  //     )
  //     break
  //   case ('phone'):
  //     inputEl = (
  //       <>
  //         <MuiPhoneNumber
  //           className={`${inputClasses} ${rtlClass} ${classes.phoneInput}`}
  //           value={value}
  //           onChange={changed}
  //           label={label}
  //           disabled={disabled}
  //           error={touched && !valid}
  //           autoFormat={false}
  //           disableAreaCodes={false}
  //           disableCountryCode={false}
  //           disableDropdown={true}
  //           regions={['north-america', 'europe']}
  //           helperText={errorMessage && errorMessage.var}
  //           {...elementSetup}
  //         />
  //       </>
  //     )
  //     break
  //   case ('video'):
  //     inputEl = (
  //       <>
  //         <TextField
  //           dir={language.direction}
  //           className={`${inputClasses} ${rtlClass} ${elementSetup.disabled && classes.disabledInput}`}
  //           label={label}
  //           value={value}
  //           onChange={changed}
  //           onBlur={blured}
  //           error={touched && !valid}
  //           helperText={errorMessage && errorMessage.var}
  //           fullWidth={grid.fullWidth}
  //           disabled={disabled}
  //           {...elementSetup}
  //         />
  //         <p className={classes.videoSupport}>Supports: YouTube, SoundCloud, Facebook, Vimeo	, Twitch, Streamable, Wistia, DailyMotion, Mixcloud, Vidyard</p>
  //         <Box className={classes.videoContainer}>
  //           <ReactPlayer controls url={value} width="100%" height="100%" />
  //           <p><b>Video Preview</b>Add video URL above to display</p>
  //         </Box>
  //       </>
  //     )
  //     break
  //   default:
  //     inputEl = (
  //       <>
  //         <TextField
  //           dir={language.direction}
  //           className={`${inputClasses} ${rtlClass} ${elementSetup.disabled && classes.disabledInput}`}
  //           label={label}
  //           value={value}
  //           onChange={changed}
  //           onBlur={blured}
  //           error={touched && !valid}
  //           helperText={errorMessage && errorMessage.var}
  //           fullWidth={grid.fullWidth}
  //           disabled={disabled}
  //           InputProps={{
  //             startAdornment: elementSetup.adornment ? <InputAdornment position={elementSetup.adornmentposition || 'start'}>{elementSetup.adornment}</InputAdornment> : null,
  //           }}
  //           {...elementSetup}
  //           type={elementSetup.type === 'password' && showPassword ? 'text' : elementSetup.type}
  //         />
  //       {elementSetup.help && (
  //         <Typography
  //           className={classes.help}
  //           style={{
  //             ...elementSetup.helpbackground ? { backgroundColor: elementSetup.helpbackground } : {},
  //             ...elementSetup.helpcolor ? { color: elementSetup.helpcolor } : {},
  //           }}
  //         >
  //           <HelpOutlineIcon
  //             style={{
  //               ...elementSetup.helpcolor ? { color: elementSetup.helpcolor } : {},
  //             }}
  //           />
  //           {elementSetup.help}
  //         </Typography>
  //       )}
  //       {elementSetup.type === 'password' && value !== '' && (
  //         <IconButton
  //           aria-label="toggle"
  //           color="primary"
  //           disabled={disabled}
  //           onClick={() => togglePasswordVisiblityHandler(elementSetup.disabled)}
  //           className={`${classes.togglePasswordVisibility} ${elementSetup.disabled && classes.disabledIcon}`}
  //         >
  //         {showPassword ? (
  //           <VisibilityIcon />
  //         ) : (
  //           <VisibilityOffIcon />
  //         )}
  //         </IconButton>
  //       )}
  //       </>
  //     )
  //     break
  // }

  return (
    <></>
  )
}

FormElement.defaultProps = {
  valid: false,
  shouldValidate: null,
  touched: false,
  errorMessage: null,
  value: null,
  elementSetup: null,
  label: null,
  elementOptions: null,
  elementType: null,
  grid: null,
  disabled: false,
  blured: null,
  formElementSpacing: 0,
}

FormElement.propTypes = {
  valid: PropTypes.bool,
  shouldValidate: PropTypes.objectOf(PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.number,
    PropTypes.array,
    PropTypes.bool,
    PropTypes.object,
  ])),
  touched: PropTypes.bool,
  errorMessage: PropTypes.objectOf(PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.number,
    PropTypes.array,
    PropTypes.bool,
    PropTypes.object,
  ])),
  value: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.number,
    PropTypes.bool,
    PropTypes.objectOf(PropTypes.oneOfType([
      PropTypes.string,
      PropTypes.number,
    ])),
    PropTypes.arrayOf(PropTypes.oneOfType([
      PropTypes.string,
      PropTypes.number,
      PropTypes.object,
    ])),
  ]),
  changed: PropTypes.func.isRequired,
  blured: PropTypes.func,
  elementSetup: PropTypes.objectOf(PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.number,
    PropTypes.bool,
    PropTypes.object,
  ])),
  label: PropTypes.string,
  elementOptions: PropTypes.arrayOf(PropTypes.objectOf(PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.number,
    PropTypes.array,
    PropTypes.bool,
    PropTypes.object,
  ]))),
  elementType: PropTypes.string,
  grid: PropTypes.objectOf(PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.number,
    PropTypes.bool,
  ])),
  disabled: PropTypes.bool,
  formElementSpacing: PropTypes.number,
}

export default FormElement
