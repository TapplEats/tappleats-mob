import { StatusBar } from 'expo-status-bar'
import React, { useContext } from 'react'
import { StyleSheet, Text, TextInput, View, SafeAreaView } from 'react-native'

import { IconButton } from '../components'
import Firebase from '../config/firebase'
import { AuthenticatedUserContext } from '../navigation/AuthenticatedUserProvider'

const auth = Firebase.auth()

//...........sectionForm..................
// const sectionForm = () => {
//   const 
//   return (
//     <SafeAreaView>
//       <TextInput
//         style={styles.input}
//         onChangeText={onChangeText}
//         value={text}
//       />
//       <TextInput
//         style={styles.input}
//         onChangeText={onChangeNumber}
//         value={number}
//         placeholder="useless placeholder"
//         keyboardType="numeric"
//       />
//     </SafeAreaView>
//   )
// }

export default function MenuScreen() {
  const { user } = useContext(AuthenticatedUserContext)
  const handleSignOut = async () => {
    try {
      await auth.signOut();
    } catch (error) {
      console.log(error)
    }
  }

  // sectionForm, itemForm, add/edit/delete section/item,

  // addHandler, editHandler, deleteHandler, 

  // modal instead of dialog

  return (
    <View style={styles.container}>
      <StatusBar style='dark-content' />
      <View style={styles.row}>
        <Text style={styles.title}>Welcome {user.email}!</Text>
        <IconButton
          name='logout'
          size={24}
          color='#fff'
          onPress={handleSignOut}
        />
      </View>
      <Text style={styles.text}>Your UID is: {user.uid} </Text>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#e93b81',
    paddingTop: 50,
    paddingHorizontal: 12
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 24
  },
  title: {
    fontSize: 24,
    fontWeight: '600',
    color: '#fff'
  },
  text: {
    fontSize: 16,
    fontWeight: 'normal',
    color: '#fff'
  },
  input: {
    height: 40,
    margin: 12,
    borderWidth: 1,
    padding: 10,
  },
})
