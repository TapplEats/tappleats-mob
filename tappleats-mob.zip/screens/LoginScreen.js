import { StatusBar } from 'expo-status-bar'
import React, { useState, useEffect } from 'react'
import { StyleSheet, Text, View, Button as RNButton } from 'react-native'

import * as Google from 'expo-auth-session/providers/google'

import { Button, InputField, ErrorMessage } from '../components'
import firebase from 'firebase/app'
import Firebase from '../config/firebase'

const auth = Firebase.auth()

export default function LoginScreen({ navigation }) {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [passwordVisibility, setPasswordVisibility] = useState(true)
  const [rightIcon, setRightIcon] = useState('eye')
  const [loginError, setLoginError] = useState('')

  const [request, response, promptAsync] = Google.useIdTokenAuthRequest({
    clientId: "451722526570-baict6n295kler04ed5p46ail7bap3d8.apps.googleusercontent.com",
  })

  useEffect(() => {
    if (response?.type === 'success') {
      const { id_token } = response.params
      
      const credential = firebase.auth.GoogleAuthProvider.credential(id_token)
      console.log(credential)
      // console.log(auth)
      firebase.auth().signInWithCredential(credential)
    }
  }, [response])

  const handlePasswordVisibility = () => {
    if (rightIcon === 'eye') {
      setRightIcon('eye-off');
      setPasswordVisibility(!passwordVisibility)
    } else if (rightIcon === 'eye-off') {
      setRightIcon('eye');
      setPasswordVisibility(!passwordVisibility)
    }
  };

  const onLogin = async () => {
    try {
      if (email !== '' && password !== '') {
        await auth.signInWithEmailAndPassword(email, password)
      }
    } catch (error) {
      setLoginError(error.message)
    }
  };

  return (
    <View style={styles.container}>
      <StatusBar style='dark-content' />
      <Text style={styles.title}>Login</Text>
      <InputField
        inputStyle={{
          fontSize: 14
        }}
        containerStyle={{
          backgroundColor: '#fff',
          marginBottom: 20
        }}
        leftIcon='email'
        placeholder='Enter email'
        autoCapitalize='none'
        keyboardType='email-address'
        textContentType='emailAddress'
        autoFocus={true}
        value={email}
        onChangeText={text => setEmail(text)}
      />
      <InputField
        inputStyle={{
          fontSize: 14
        }}
        containerStyle={{
          backgroundColor: '#fff',
          marginBottom: 20
        }}
        leftIcon='lock'
        placeholder='Enter password'
        autoCapitalize='none'
        autoCorrect={false}
        secureTextEntry={passwordVisibility}
        textContentType='password'
        rightIcon={rightIcon}
        value={password}
        onChangeText={text => setPassword(text)}
        handlePasswordVisibility={handlePasswordVisibility}
      />
      {loginError ? <ErrorMessage error={loginError} visible={true} /> : null}
      <Button
        onPress={onLogin}
        backgroundColor='#f57c00'
        title='Login'
        tileColor='#fff'
        titleSize={20}
        containerStyle={{
          marginBottom: 24
        }}
      />
      <Button
        disabled={!request}
        title="Login With Google"
        onPress={() => promptAsync()}
      />
      <RNButton
        onPress={() => navigation.navigate('Signup')}
        title='Go to Signup'
        color='#fff'
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#e93b81',
    paddingTop: 50,
    paddingHorizontal: 12
  },
  title: {
    fontSize: 24,
    fontWeight: '600',
    color: '#fff',
    alignSelf: 'center',
    paddingBottom: 24
  }
})

// import React, { useEffect } from 'react'
// import { connect } from 'react-redux'
// import PropTypes from 'prop-types'

// import firebase from 'firebase/app'
// import { GoogleAuthProvider } from 'firebase/auth'

// import { firebaseApp } from '../API/firebase'

// // import {
// //   ResponseType,
// //   useAuthRequest,
// //   useAutoDiscovery,
// // } from "expo-auth-session"

// import * as Google from 'expo-auth-session/providers/google'
// // import * as WebBrowser from 'expo-web-browser'

// import { View, Button } from 'react-native'

// import { useAuth } from '../hooks/use-auth'

// import * as actions from '../store/actions'

// // import {
// //   updateLoginDates,
// // } from '../API/users'

// // WebBrowser.maybeCompleteAuthSession()

// const LoginScreen = ({ onSetNotification }) => {
//   const auth = useAuth()
//   // const useProxy = Platform.select({ web: false, default: true })
//   // const discovery = useAutoDiscovery("https://accounts.google.com")

//   // const [accessToken, setAccessToken] = useState(null)

//   // const [request, response, promptAsync] = useAuthRequest(
//   //   {
//   //     clientId: Platform.select({
//   //       web:
//   //         "451722526570-baict6n295kler04ed5p46ail7bap3d8.apps.googleusercontent.com",
//   //     //  default: "you do not have this yet"
//   //     }),
//   //     // redirectUri: makeRedirectUri({
//   //     //   // For usage in bare and standalone
//   //     //   native:
//   //     //     "you do not have this yet",
//   //     //   useProxy,
//   //     // }),
//   //     usePKCE: false,
//   //     responseType: ResponseType.Token,
//   //     scopes: ["openid", "profile"],
//   //   },
//   //   discovery
//   // );

//   const [request, response, promptAsync] = Google.useIdTokenAuthRequest({
//     clientId: "451722526570-baict6n295kler04ed5p46ail7bap3d8.apps.googleusercontent.com",
//   })

//   // const [request, response, promptAsync] = Google.useAuthRequest({
//   //   expoClientId: "877105628079-r82vhp2egk35pkoi1gnpmdto54bpt870.apps.googleusercontent.com",
//   // })

//   useEffect(() => {
//     if (response?.type === 'success') {
//       const { id_token } = response.params;
      
//       // const auth = getAuth();
//       const credential = GoogleAuthProvider.credential(id_token);
//       firebaseApp.auth().signInWithCredential(auth, credential);
//     }
//   }, [response])

//   // useEffect(() => {
//   //   if (response?.type === "success") {
//   //     setAccessToken(response.authentication.accessToken)
//   //   }
//   // }, [response])

//   // useEffect(() => {
//   //   let mounted = true
//   //   if (mounted) {
//   //     (async () => {
//   //       try {
//   //         if (auth.authStatus === 'loggedin' && auth.user && auth.userExist) {
//   //           await updateLoginDates(auth.user.uid)
//   //         }
//   //       } catch (err) {
//   //         onSetNotification({
//   //           message: 'There was a problem logging-in.',
//   //           type: 'error',
//   //         })
//   //       }
//   //     })()
//   //   }
//   //   return () => { mounted = false }
//   // }, [
//   //   auth.authStatus,
//   //   auth.user,
//   //   auth.userExist,
//   //   onSetNotification,
//   // ])

//   return (
//     <View>
//       <Button
//         disabled={!request}
//         title="Login"
//         onPress={() => {
//           promptAsync()
//         }}
//       />
//     </View>
//   )
// }

// LoginScreen.propTypes = {
//   onSetNotification: PropTypes.func.isRequired,
// }

// const mapDispatchToProps = dispatch => ({
//   onSetNotification: (notification, duration) => dispatch(actions.setNotification(notification, duration)),
// })

// export default connect(null, mapDispatchToProps)(LoginScreen)