import React, { useState, useEffect } from "react"
// import { StatusBar } from "expo-status-bar"
import { StyleSheet, Text, View, Button } from "react-native"

// import ReduxThunk from 'redux-thunk'
// import { Provider } from 'react-redux'
// import {
//   createStore, applyMiddleware, combineReducers,
// } from 'redux'

// import { ResponseType } from 'expo-auth-session'
import * as WebBrowser from 'expo-web-browser'
// import * as Google from 'expo-auth-session/providers/google'

// import firebase, { initializeApp } from "firebase/app"
// import { getAuth, onAuthStateChanged, GoogleAuthProvider, signInWithCredential } from "firebase/auth"
// import "firebase/auth"
// import { getFirebaseAuth } from "./app/API/firebase"

// import * as vars from './app/utilities/appVars'

// import notificationReducer from './app/store/reducers/notification'

// import LoginScreen from "./app/screens/LoginScreen"
// import RootNavigation from './app/navigation/index'
import Routes from "./navigation"

// const rootReducer = combineReducers({
//   notification: notificationReducer,
// })

// const store = createStore(
//   rootReducer,
//   applyMiddleware(ReduxThunk),
// )

// initializeApp(vars.FIREBASE_CONFIG)
// const firebaseApp = !firebase.apps.length
//   ? firebase.initializeApp(vars.FIREBASE_CONFIG)
//   : firebase.app()
// const googleProvider = new GoogleAuthProvider()
// const auth = getAuth(firebaseApp)

WebBrowser.maybeCompleteAuthSession()

export default function App() {
  // const [user, setUser] = useState(null)
  // const [request, response, promptAsync] = Google.useIdTokenAuthRequest({
  //   clientId: "451722526570-baict6n295kler04ed5p46ail7bap3d8.apps.googleusercontent.com",
  // })

  // useEffect(() => {
  //   onAuthStateChanged(auth, authUser => {
  //     if (authUser) {
  //       setUser(user)
  //     } else {
  //       setUser(null)
  //     }
  //   })
  // })

  // useEffect(() => {
  //   if (response?.type === 'success') {
  //     const { id_token } = response.params;

  //     const credential = googleProvider.credential(id_token)
  //     signInWithCredential(auth, credential)
      
  //     // const auth = firebase.auth.getAuth();
  //     // const credential = firebase.auth.GoogleAuthProvider.credential(id_token);
  //     // firebase.auth.signInWithCredential(auth, credential);
  //     console.log('connected')
  //   }
  // }, [response])

  return (
    <Routes />
    // <Provider store={store}>
    //   {/* <View style={styles.container}>
    //     <Text>Tappl Eats</Text>
    //     <StatusBar style="auto" />
    //   </View> */}
    //   {/* <RootNavigation /> */}
    //   <View style={styles.container}>
    //     {user ? 
    //       <Text>
    //         Welcome {user}
    //       </Text>
    //         :
    //       <Button
    //         disabled={!request}
    //         title="Login"
    //         onPress={() => {
    //           promptAsync()
    //         }}
    //       />
    //     }
        

    //   </View>
    // </Provider>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
})
